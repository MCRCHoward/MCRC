// Baseline migration: mark current schema as applied (no changes).
export async function up(): Promise<void> {
  // no-op
}

export async function down(): Promise<void> {
  // no-op
}
