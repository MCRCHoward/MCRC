const ServicesPage = () => {
  return <h1>I am alive</h1>
}

export default ServicesPage
