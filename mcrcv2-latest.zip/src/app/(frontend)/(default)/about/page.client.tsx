'use client'

import React from 'react'

const PageClient: React.FC = () => {
  return null
}

export default PageClient
