export default function ThankYouPage() {
  return <div>ThankYouPage</div>
}
