// Disabled GraphQL for static export builds.
export const dynamic = 'force-dynamic'

export async function GET() {
  return new Response('GraphQL endpoint is not available in this static build.', { status: 404 })
}

export async function POST() {
  return new Response('GraphQL endpoint is not available in this static build.', { status: 404 })
}
